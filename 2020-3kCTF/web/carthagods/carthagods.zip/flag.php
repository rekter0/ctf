<?php

$flag="3k{Hail_the3000_years_7hat_are_b3h1nd}";

echo '<iframe width="560" height="315" src="https://www.youtube.com/embed/y8zZXMLBin4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
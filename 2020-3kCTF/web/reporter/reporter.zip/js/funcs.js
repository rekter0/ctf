function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

$(function() {
  $("#filecontent").hide();
  $("#loading").hide();
  $("#alert").hide();
  $("#result_link").hide();
    $("#edit").click(function() {
      $("#filecontent").hide();
      $("#mdcontent").show();
      return false;
    });
    $("#preview").click(function() {
      $("#filecontent").show();
      document.getElementById("filecontent").innerHTML = "";
     
      text = document.getElementById("mdcontent").value
      var md = new Remarkable();
      md.set({
          html: true,
          breaks: true
      });
      html = md.render(text);
      document.getElementById("filecontent").innerHTML = html;
      $("#mdcontent").hide();

      document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightBlock(block);
      });
      document.querySelectorAll('p code').forEach((block) => {
        block.classList.add("plainstyle");
        
      });
      return false;
      
    });

    $("form").submit(function(e){
      e.preventDefault();
      return false;
    });

    $("#save").click(async function() {
      $("#mdcontent").hide();
      $("#filecontent").hide();
      $("#mdcontent").show();
      $("#loading").show();
      await sleep(1000);
      var fcont = $('#filecontent').html();
      var mdcont = document.getElementById("mdcontent").value;
      data = "mdcontent=" + encodeURI(mdcont) + "&filecontent=" + encodeURI(fcont);
      $.ajax({
        type: "POST",
        url: "./backend.php",
        data: data,
        success: function(resp) {
          if(resp == "done"){
            $("#loading").hide();
            $('label#alert').show();
            $('label#alert').removeClass();
            $('label#alert').addClass("label label-success");
            $('label#alert').text("Saved successfully").hide().fadeIn(2500,function(){
            $('label#alert').hide();
            });
          }else{
            alert(resp);
            $("#loading").hide();
            $('label#alert').show();
            $('label#alert').removeClass();
            $('label#alert').addClass("label label-warning");
            $('label#alert').text("Error while saving ").hide().fadeIn(2500,function(){
            $('label#alert').hide();
            });
          }
        }
      });
      return false;      
    });
    $("#deliver").click(async function() {
      $("#loading").show();
      await sleep(1000);
      $.ajax({
        type: "POST",
        url: "./backend.php",
        data: "deliver=true",
        success: function(resp) {
          
            $("#loading").hide();
            $('label#alert').show();
            $('label#alert').removeClass();
            $('label#alert').addClass("label label-success");
            $('label#alert').html('<br/><br/><a href="'+resp+'" target="_blank">REPORT</a>');
          
        }
      });
      return false;
    });
});

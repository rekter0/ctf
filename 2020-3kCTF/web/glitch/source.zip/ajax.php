<?php
include 'conf.php';


if(@$_POST['usr'] AND @$_POST['pw']){
	if($auth=authenticate($_POST['usr'],$_POST['pw'])){
		$msg='login success';
		$AuthCookie=bake_cookie($auth);
		out(array(
			$msg,$AuthCookie,$auth['user']
		));
	}else{
		$msg='login failed';
		out(array(
			$msg
		));
	}
}

if(@$_POST['Auth'] AND @$_POST['User']){
	out(isLogged($_POST['Auth'],$_POST['User']));
}


echo 'end';
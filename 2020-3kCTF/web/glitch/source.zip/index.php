<?php

	if (@$_GET['page']=='login'){
		$page= 'xlogin.php';
	}elseif (@$_GET['page']=='secrets') {
		$page= 'xsecrets.php';
	}elseif (@$_GET['page']=='info') {
		$page= 'xinfo.php';
	}else{
		$page= 'xmain.php';
	}

?>
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta charset="UTF-8">
		<title>GLITCH</title>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.css">				
		<link rel="stylesheet" href="css/main.css">
		<script src="files/jquery-1.9.1.min.js"></script>
		</head>
		<body>	
		  <header id="header">
		    <div class="container main-menu">
		    	<div class="row align-items-center justify-content-between d-flex">
			      <div id="logo">
			        <a href="./"><img src="img/logo.png" alt="" title="" width="120" /></a>
			      </div>
			      <nav id="nav-menu-container">
			        <ul class="nav-menu">
			          <li><a href="./">Home</a></li>
			          <li><a href="./?page=login">Login</a></li>
			          <li><a href="./?page=secrets">Secrets</a></li>
			          <li><a href="./?page=info">phpinfo</a></li>
			        </ul>
			      </nav>		    		
		    	</div>
		    </div>
		  </header>
			<?php
				include $page;
			?>
            
		</body>
		
	</html>
		<section class="banner-area">
				<div class="container">
					<div class="row fullscreen align-items-center justify-content-between">
						<div class="col-lg-6 col-md-6 banner-left">
							<div id="msg" style="display: none;"><h2 id="msgtext"></h2><br/><br/></div>
							<div id="viewform" style="display: none;">
								<h6>View Secrets</h6>
								<p>
									
								</p>
							</div>
							
						</div>
						<div class="col-lg-6 col-md-6 banner-right ">
							<img class="img-fluid" src="img/glitch.gif" alt="">
						</div>
					</div>
				</div>					
			</section>

			<script>
			    jQuery(function( $ ) {
			    	if(typeof localStorage.Auth =='undefined' || typeof localStorage.User=='undefined'){
			    		$('#msg').css('display','');
				        $('#msgtext').html('Login to view secrets!');
			    	}else{
			    		$.post("ajax.php", {Auth: localStorage.Auth,User:localStorage.User}, function(result){
				            thisRes = JSON.parse(result);
				            if(thisRes[0]=='OK'){
				              	$('#viewform').css('display','');
				              	$.each(thisRes[1], function( index, value ) {
								  $('#viewform').append(value+"<br/>");
								});
				            }else{
				            	$('#msg').css('display','');
				            	$('#msgtext').html('Login to view secrets!');
				            }
				                 
				        });

			    		
			    	}
				});    
			</script>
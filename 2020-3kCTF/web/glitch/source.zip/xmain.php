		<section class="banner-area">
				<div class="container">
					<div class="row fullscreen align-items-center justify-content-between">
						<div class="col-lg-6 col-md-6 banner-left">
							<p>
								kthxbye
							</p>
							
						</div>
						<div class="col-lg-6 col-md-6 banner-right ">
							<img class="img-fluid" src="img/glitch.gif" alt="">
						</div>
					</div>
				</div>					
			</section>
		<section class="banner-area">
				<div class="container">
					<div class="row fullscreen align-items-center justify-content-between">
						<div class="col-lg-6 col-md-6 banner-left">
							<div id="msg" style="display: none;"><h2 id="msgtext"></h2><br/><br/></div>
							<h6>Login</h6>
							<p>
								<form method="POST" action="">
									<input type='text' id='username' placeholder="username" required/><br/>
									<input type='password' id='password' placeholder="password" required/><br/>
									<input type='submit' value="login!"><br/>
								</form>
							</p>
						</div>
						<div class="col-lg-6 col-md-6 banner-right ">
							<img class="img-fluid" src="img/glitch.gif" alt="">
						</div>
					</div>
				</div>					
			</section>

			<script>
			    jQuery(function( $ ) {
			    	$('form').on('submit',function(e){
			    		e.preventDefault();
			    		var username=$('#username').val();
			    		var password=$('#password').val();
			    		if(username !='' && password !=''){
			    			$.post("ajax.php", {usr: username,pw:password}, function(result){
				                thisRes = JSON.parse(result);
				                $('#msg').css('display','');
				                $('#msgtext').html(thisRes[0]);

				                if(thisRes[0]=='login success'){
				                	localStorage.Auth = thisRes[1];
				                	localStorage.User = thisRes[2];
				                	setTimeout(function(){ document.location="./?"; }, 3000);
				                }
				                 
				            });
				                
			    		}
			    	});
				});    
			</script>